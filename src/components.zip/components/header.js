import React from "react";

function Header() {
    const name = "Arvind";
    return (
        <>
            <h1>Hello World</h1>
            <h2>Welcome {name}!</h2>
        </>
    );
}

export default Header;