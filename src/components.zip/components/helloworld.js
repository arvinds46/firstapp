import React from "react";

class HelloWorld extends React.Component {
    render() {
        return (
            <div>
                <h1>HelloWorld From Class Component</h1>
            </div>
        )
    }
}

export default HelloWorld;